package com.br.accenture.eBank.ebank.entities.enums;

public enum TipoConta {

	CORRENTE,
	POUPANCA
	
}

package com.br.accenture.eBank.ebank.dtos.auth;

public record AuthenticationDTO(String cpf, String senha) {

}

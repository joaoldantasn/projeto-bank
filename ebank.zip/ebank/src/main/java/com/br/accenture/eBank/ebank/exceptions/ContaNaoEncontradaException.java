package com.br.accenture.eBank.ebank.exceptions;


public class ContaNaoEncontradaException extends RuntimeException {

    public ContaNaoEncontradaException(String message) {
        super(message);
    }
}

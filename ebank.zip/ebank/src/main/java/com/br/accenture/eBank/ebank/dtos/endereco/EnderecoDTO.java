package com.br.accenture.eBank.ebank.dtos.endereco;

public record EnderecoDTO(String cep, String logradouro, String cidade, String bairro, String numero) {

}

package com.br.accenture.eBank.ebank.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.br.accenture.eBank.ebank.entities.Endereco;

public interface EnderecoRepository extends JpaRepository<Endereco, Long>{

}

package com.br.accenture.eBank.ebank.entities.enums;

public enum Operacao {
	
	SAQUE,
	DEPOSITO,
	TRANSFERENCIA,
	TRANSFERENCIA_PIX
	
}

package com.br.accenture.eBank.ebank.dtos.auth;

public record LoginResponseDTO(String token) {

}
